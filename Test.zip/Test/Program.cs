﻿int result = 5;

int x = result;

Console.WriteLine(x);